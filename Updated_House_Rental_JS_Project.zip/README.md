# House Rental (JavaScript Version)

- Fully converted from TypeScript to JavaScript.
- Built with Next.js and React.
- No TypeScript used.

## Setup

```bash
npm install
npm run dev
```