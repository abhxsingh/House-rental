const express = require('express');
const router = express.Router();
const { getProperties, createProperty } = require('../controllers/propertyController');
const { protect } = require('../middlewares/authMiddleware');

router.route('/').get(getProperties).post(protect, createProperty);

module.exports = router;
