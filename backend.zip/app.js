const express = require('express');
const app = express();
const propertyRoutes = require('./routes/propertyRoutes');
const authRoutes = require('./routes/authRoutes');
const { connectDB } = require('./config/db');

require('dotenv').config();

connectDB();

app.use(express.json());

app.use('/api/properties', propertyRoutes);
app.use('/api/auth', authRoutes);

module.exports = app;
