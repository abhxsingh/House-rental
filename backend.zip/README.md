# House Rental Backend

This is the backend API for the House Rental system.

## Setup

- Install dependencies: `npm install`
- Start server: `npm run dev`

## Environment Variables

See `.env.example` for required environment variables.
