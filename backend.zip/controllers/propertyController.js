exports.getProperties = (req, res) => {
  res.send('Get all properties');
};

exports.createProperty = (req, res) => {
  res.send('Create new property');
};
