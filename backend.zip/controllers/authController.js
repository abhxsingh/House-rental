exports.registerUser = (req, res) => {
  res.send('Register user');
};

exports.loginUser = (req, res) => {
  res.send('Login user');
};
