// Future validators (e.g., email format, password strength)
